import axios from 'axios';
export function getContracts(channel: string) { return axios.get('/contracts', { params: { channel } }); }

<script setup lang="ts">
import { getContracts } from '../api/contracts';
getContracts('web');
</script>
<template><div>合成示例</div></template>
